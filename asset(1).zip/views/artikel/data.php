<?php
return array(
	'Desember 2013' => array(
	    'cara-ringkas-menggantung-object-di-tembok-dari-bata-ringan-aac'=>array(
	    	'title' => 'Cara ringkas menggantung object di tembok dari bata ringan AAC',
	        'file'=>'2013-12-11-001.twig',
	        'image' => 'ill-example-news.jpg',
	        'thumb' => 'ill-example-news-thumb.jpg',
	        'desc'=>'Dengan
menggunakan Fischer, bracket dikunci dengan sekrup sehingga akan mudah dilepas pasang
jika dibandingkan dengan di paku...',
	    ),
	    'blesscon-gelar-gathering-bersama-spg'=>array(
	    	'title' => 'Blesscon gelar gathering bersama SPG',
	        'file'=>'2013-12-11-002.twig',
	        'image' => 'ill-example-news.jpg',
	        'thumb' => 'ill-example-news-thumb.jpg',
	        'desc'=>'Dalam rangka membina relasi untuk lebih dekat
antara Blesscon dan SPG toko distributor, Manajer Marketing Blesscon menggelar
gathering bersama SPG toko...',
	    ),
	)
);
