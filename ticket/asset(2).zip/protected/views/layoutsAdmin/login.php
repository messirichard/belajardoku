<?php /* @var $this Controller */ ?>
<?php $this->beginContent('//layoutsAdmin/mainLogin'); ?>
<div class="container">
	<?php echo $content ?>
</div>
<?php $this->endContent(); ?>