<div class="popup-container">
	<div class="height-15"></div>
	<div class="popup-logo">
		<img src="<?php echo Yii::app()->baseUrl; ?>/asset/images/logo-popup-glow.jpg" alt="">
	</div>
	<div class="popup-link-header">
		CART
	</div>
	<div class="clear"></div>
	<div class="height-5"></div>
	<div class="popup-border-container">
		<div class="text-content small">
			<div class="height-10"></div>
			<div class="height-10"></div>
			<div align="center">Tidak ada item di keranjang belanja</div>
			<div class="height-10"></div>
			<div class="height-10"></div>
		</div>
	</div>
</div>
