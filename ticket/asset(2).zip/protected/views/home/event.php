<div class="outer-middle">
	<div class="prelatif container">
			<div class="fcs-wrap region h222 prelatif">
				<div class="ill-page-inside"><img src="<?php echo Yii::app()->baseUrl; ?>/asset/images/ill-event-gallery.jpg" alt="ill Event Gallery cheetam salt"></div>
				<div class="clearfix"></div>
			</div>
			<div class="clear height-15"></div>
			<div class="height-1"></div>
			<div class="region inside-content prelatif">
				<div class="clear height-5"></div>
				<div class="height-2"></div>

				<div class="left left-content-ins margin-right-35">
					<div class="ins">
						<h2 class="title">Event Gallery</h2>
						<div class="clear height-10"></div>
						<div class="lines-blue"></div>
						<div class="clear height-5"></div>

						<div class="menu-inside">
							<ul>
								<li><a href="#">July 2013</a>
									<ul>
										<li class="active"><a href="#">Event Name over here</a></li>
									</ul>
								</li>
								<li class="separator"></li>
								<li><a href="#">Juni 2013</a></li>
								<li class="separator"></li>
								<li><a href="#">May 2013</a></li>
								<li class="separator"></li>
							</ul>
						</div>

						<div class="clear"></div>
					</div>
				</div>
				<div class="left right-content">
						<div class="clear height-20"></div>
						<div class="right breadcumb"><a href="#">Home</a> &gt; <b>Event Gallery</b></div>
						<div class="clear height-25"></div>
						<div class="content-text">
							<h5>Event Name over here (example: Asian Food Expo - Singapore 2013)</h5>
							<p>Event Name over here (example: Asian Food Expo - Singapore 2013) Penjelasan singkat mengenai acara dan partisipasi Cheetam di acara tersebut. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Error illum neque sed quis fugit ullam nam! Illum, harum totam vitae eos neque ut in. Maxime, quas, quis officia vitae et nobis repudiandae officiis totam ducimus optio eos sed sint tempore! Click on the thumbnail to enlarge.</p>
							
							<div class="clear height-10"></div>
							<div class="list-gallery">
								<div class="row">
									<?php for ($i=0; $i < 3; $i++) { ?>
									<div class="col-xs-3">
										<div class="item"><img src="<?php echo Yii::app()->baseUrl; ?>/asset/images/event-example.jpg" alt=""></div>
									</div>
									<div class="col-xs-3">
										<div class="item"><img src="<?php echo Yii::app()->baseUrl; ?>/asset/images/event-example.jpg" alt=""></div>
									</div>
									<div class="col-xs-3">
										<div class="item"><img src="<?php echo Yii::app()->baseUrl; ?>/asset/images/event-example.jpg" alt=""></div>
									</div>
									<div class="col-xs-3">
										<div class="item"><img src="<?php echo Yii::app()->baseUrl; ?>/asset/images/event-example.jpg" alt=""></div>
									</div>
									<?php } ?>
									<div class="clearfix"></div>
								</div>
								<div class="clear height-20"></div>
							</div>
							<div class="clear height-20"></div>

							<div class="clear"></div>
						</div>

					<div class="clearfix"></div>
				</div>
				<div class="clear"></div>
			</div>

			<div class="clear height-10"></div>
			<div class="height-2"></div>
			
		<div class="clearfix"></div>
	</div>
	<div class="clear"></div>
</div>