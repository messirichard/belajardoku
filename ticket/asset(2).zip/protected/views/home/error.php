<div class="outers-data-inside-about mw-950 tengah">
    <div class="tagline-home text-center">
        Error <?php echo $error['code'] ?>
    </div>
    <div class="height-20"></div>
    <div class="tjadwal-peluncuran">
        <p class="text-center"><?php echo CHtml::encode($error['message']); ?></p>

        <div class="clear"></div>
    </div>

    <div class="clear height-40"></div>

    <div class="clear"></div>
</div>
