<div class="border-orange">
	<div class="padding-40">
		<div class="add-cart-container">
			<div class="add-cart-image">
				<img src="http://localhost/pandaku/images/product/.tmb/thumb_2ee82-PR%2031798%20_resize_170_170.jpg" alt="">
			</div>
			<div class="add-cart-content">
				<div class="add-cart-qty">
					1 produk:
				</div>
				<h1>Toilet Napkin Bajocero with anticeptic</h1>
				<h2>Telah berhasil ditambahkan ke cart (keranjang belanja)</h2>
                <a href="<?php echo CHtml::normalizeUrl(array('')); ?>" class="btn btn-add-to-cart">
                    Lanjut Belanja
                </a>
                <a href="<?php echo CHtml::normalizeUrl(array('')); ?>" class="btn btn-add-to-cart">
                    Lihat Cart
                </a>
			</div>
			<div class="clear"></div>
		</div>
	</div>
</div>