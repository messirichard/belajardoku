<section class="top-content-inside about">
    <div class="container">
        <div class="titlepage-Inside">
            <h1>About Us</h1>
        </div>
    </div>
    <div class="celar"></div>
</section>
<section class="middle-content">
        <div class="prelatife container">
            <div class="content-text">
                <div class="clear height-50"></div>
                <div class="height-5"></div>
                <div class="row">
                    <div class="col-md-6">
                        <h2>We&#39;ll help you to <span>understand,</span> <br>
                            the best solution for you...</h2>
                        <h4>Get your information protected, DV Computers <br>
                            will help you with Desktops & Laptops repairs, <br>
                            virus removal, and data backup.</h4>

                <p>Established in 2001, WA owned company <br>

                Experienced skills in hardware and software fixes i.e. virus, data backup, hardware upgrade, server<br>

                In house tech for a quick turnaround result<br>

                Large second hand IT equipment – full warrant<br>

                Support available for local small to medium business<br>

                Onsite support available<br>

                Agent for ASUS, FUJITSU, TOSHIBA, ACER, SONY, HP, DELL, IBM (LENOVO), SAMSUNG, MSI<br>

                Certified Microsoft refurbisher<br>
                Apple repairer</p>
                <img src="<?php echo Yii::app()->baseUrl ?>/asset/images/about-logo.jpg" class="img-responsive" alt="">

                            <div class="clearfix"></div>
                    </div>
                    <div class="col-md-6">
                        <div class="featured-image"><img class="img-responsive" src="<?php echo Yii::app()->baseUrl; ?>/asset/images/ill-about-dv-computers.png" alt=""></div>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="clear height-50"></div>
            </div>
            <div class="clear"></div>
        </div>
    <div class="clear"></div>
</section>