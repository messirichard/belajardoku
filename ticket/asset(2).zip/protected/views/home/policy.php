<div class="outer-middle">
	<div class="prelatif container">
			<div class="fcs-wrap region h222 prelatif">
				<div class="ill-page-inside"><img src="<?php echo Yii::app()->baseUrl; ?>/asset/images/ill-career.jpg" alt="ill Career cheetam salt"></div>
				<div class="clearfix"></div>
			</div>
			<div class="clear height-15"></div>
			<div class="height-1"></div>
			<div class="region inside-content prelatif">
				<div class="clear height-5"></div>
				<div class="height-2"></div>

				<div class="left left-content-ins margin-right-35">
					<div class="ins">
						<h2 class="title">Privacy Policy</h2>
						<div class="clear height-10"></div>
						<div class="lines-blue"></div>
						<div class="clear height-5"></div>

						<div class="clear"></div>
					</div>
				</div>
				<div class="left right-content">
						<div class="clear height-20"></div>
						<div class="right breadcumb"><a href="<?php echo CHtml::normalizeUrl(array('/home/index', 'lang'=>Yii::app()->language)); ?>">Home</a> &gt; <b>Privacy Policy</b></div>
						<div class="clear height-25"></div>
						<div class="content-text">
							<?php echo $this->setting['privacy_content'] ?>
							<?php /*
							<h5>Apakah Anda kandidat yang kami cari?</h5>
							<p>Mari bergabung bersama Cheetam Salt, perusahaan garam terbesar dan terbaik di duia. Anda akan memiliki jenjang karir yang jelas untuk masa depan Anda. Sebagai perusahaan internasional, kami tidak pernah berhenti merekrut kandidat yang kreatif, berpengalaman dan memiliki kemampuan yang tinggi.</p>
							<p>Silahkan kirim CV anda dengan form di bawah ini dan ceritakan mengapa Cheetam Salt membutuhkan Anda. Anda mungkin kandidat yang kami cari.</p>
							*/ ?>
							<div class="clear height-20"></div>

							<div class="clear"></div>
						</div>

					<div class="clearfix"></div>
				</div>
				<div class="clear"></div>
			</div>

			<div class="clear height-10"></div>
			<div class="height-2"></div>
			
		<div class="clearfix"></div>
	</div>
	<div class="clear"></div>
</div>