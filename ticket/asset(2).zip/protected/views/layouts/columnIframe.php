<?php /* @var $this Controller */ ?>
<?php $this->beginContent('//layouts/mainIframe'); ?>
<?php echo $content ?>
<?php $this->endContent(); ?>