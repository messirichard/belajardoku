<div class="back-purple h128">
    <div class="clear height-25"></div><div class="height-2"></div>
    <div class="text-center inx-tpurple tengah">
        <span class="tl-instagram">#decibelsfestival</span>
        <div class="clear height-15"></div> <div class="height-3"></div>
        <div class="socials-bpurp">
            <span class="disn-block">FOLLOW US ON SOCIAL MEDIA</span>
            <div class="disn-block padding-left-20" style="font-size: 17px; color: #fff;">
                <a href="https://instagram.com/decibelsfestivals/" target="_blank"><i class="fa fa-instagram"></i></a>
                &nbsp;&nbsp;&nbsp;&nbsp;
                <a href="https://twitter.com/decibelsfest" target="_blank"><i class="fa fa-twitter"></i></a>
                &nbsp;&nbsp;&nbsp;&nbsp;
                <a href="https://www.facebook.com/pages/Decibels-Festivals/420368154818731" target="_blank"><i class="fa fa-facebook-square"></i></a>
                &nbsp;&nbsp;&nbsp;&nbsp;<img src="{{ app.request.baseurl }}/asset/images/bbm-icon.png" style="margin-top: -4px;" alt="">&nbsp;&nbsp;&nbsp;<span style="font-family: 'Roboto', sans-serif; letter-spacing: 0px; font-size: 16px; font-weight: 300;">594D774B</span>
            </div>
            <div class="clear"></div>
        </div>

        <div class="clear"></div>
    </div>
    
    <div class="clear"></div>
</div>
<footer class="foot">
    <div class="clear height-35"></div> <div class="height-3"></div>
    <div class="text-footer text-center tengah">
        <a href="<?php echo Yii::app()->baseUrl ?>/../"><img src="<?php echo Yii::app()->baseUrl ?>/../asset/images/logo-decibles-footer.png" alt=""></a>
        <div class="clear height-15"></div>
        <span class="tf-bottom-contact" style="display: block; text-align: center;">
            EMAIL: decibelsfestival@gmail.com <br> 
            PHONE: 031 5311098 <br> 
            ALAMAT: Plaza Tunjungan 1 Lt 7
        </span>
        <span class="tf-bottom-contact" style="display: block; text-align: center;">HOTLINE: 081 2351 72261 <br> 
            <small>(SMS or Whats App only)</small>  {# &nbsp;&nbsp;|&nbsp;&nbsp; <a href="#">CONTACT</a> #}</span>
        <div class="clear height-15"></div>

        <div class="t-copyright">
            Copyright &copy; 2015 Ten Production. All Rights Reserved. Website design <a href="http://www.markdesign.net" target="_blank" title="Website Design Surabaya">by Mark Design</a>.
        </div>

        <div class="clear"></div>
    </div>
    
    <div class="clear"></div>
</footer>