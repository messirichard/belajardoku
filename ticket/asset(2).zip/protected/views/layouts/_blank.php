<?php /* @var $this Controller */ ?>
<?php // $this->beginContent('//tampilan/main'); ?>
<?php echo $content ?>
<?php // $this->endContent(); ?>