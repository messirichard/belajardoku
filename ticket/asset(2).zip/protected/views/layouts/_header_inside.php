<header class="head header-inside">
    <div class="back-header-out">
        <?php echo $this->renderPartial('/layouts/in_headerdata'); ?>
    </div>
    <?php echo $this->renderPartial('/layouts/_header_respons'); ?>
</header>
