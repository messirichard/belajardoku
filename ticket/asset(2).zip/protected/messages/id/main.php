<?php return array(
	 // Menu
	"home"=>"Home",
	"about us"=>"About Us",
	"products"=>"Products",
	"event gallery"=>"Event Gallery",
	"career"=>"Career",
	"contact us"=>"Contact Us",
	"lokasi kami"=>"Lokasi Kami",
	"hubungi kami"=>"Hubungi Kami",
	"privacy policy"=>"Privacy Policy",
	"site map"=>"Site Map",
	 // Banner
	"tentang"=>"Tentang",
	"produk"=>"Produk",
	"berkarir di"=>"Berkarir di",
	 // Request Company Profile
	"request"=>"Request",
	"company profile"=>"Company Profile",
	 // General
	"phone"=>"Phone",
	"fax"=>"Fax",
	"email"=>"Email",
	"nama"=>"Nama",
	"lebih lanjut"=>"Lebih Lanjut",
	 // Form
	"nama anda"=>"Nama Anda",
	"email anda"=>"Email Anda",
	 // Banner
	"cheetam garam"=>"Cheetam Garam",
	 // Page
	"cheetam salt overview"=>"Cheetam Salt Overview",
	"history"=>"History",
	"pt. cheetham garam indonesia"=>"PT. Cheetham garam Indonesia",
);