<?php return array(
	 // Menu
	"home"=>"Home",
	"products"=>"Products",
	"about us"=>"About Us",
	"event gallery"=>"Event Gallery",
	"career"=>"Career",
	"contact us"=>"Contact Us",
	"lokasi kami"=>"Our Location",
	"hubungi kami"=>"Contact Us",
	"privacy policy"=>"Privacy Policy",
	"site map"=>"Site Map",
	 // Banner
	"tentang"=>"About",
	"produk"=>"Product",
	"berkarir di"=>"Career In",
	 // Request Company Profile
	"request"=>"Request",
	"company profile"=>"Company Profile",
	 // General
	"phone"=>"Phone",
	"fax"=>"Fax",
	"email"=>"Email",
	"nama"=>"Name",
	"lebih lanjut"=>"Read More",
	 // Form
	"nama anda"=>"Your Name",
	 // Banner
	"cheetam garam"=>"Cheetam Salt",
	 // Form
	"email anda"=>"Yaout Email",
	 // Page
	"cheetam salt overview"=>"Cheetam Salt Overview",
	"history"=>"History",
	"pt. cheetham garam indonesia"=>"PT. Cheetham garam Indonesia",
);